package com.flowers.takehome.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flowers.takehome.dto.TakeHomeDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;
import com.flowers.takehome.service.TakeHomeService;

@RestController
@RequestMapping("/takehome")
public class TakeHomeController {
	
	@Autowired TakeHomeService takeHomeService;
	
	@PostMapping("/process")
	public ResponseEntity<TakeHomeDTO> process(@RequestBody List<TakeHomeInputVal> 
			takeHomeInputValList) {
		if(null == takeHomeInputValList)
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		TakeHomeDTO takeHomeDTO = takeHomeService.process(takeHomeInputValList);
		return new ResponseEntity<TakeHomeDTO>(takeHomeDTO, HttpStatus.OK);
	}

}
