package com.flowers.takehome.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flowers.takehome.dto.UsersDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;
import com.flowers.takehome.service.TakeHomeService;

import lombok.extern.slf4j.Slf4j;

/**
 * to handle the request
 *
 */
@RestController
@RequestMapping("/takehome")
@Slf4j
public class TakeHomeController {
	@Autowired TakeHomeService takeHomeService;
	
	@PostMapping("/users/count")
	public ResponseEntity<UsersDTO> usersCount(@RequestBody List<TakeHomeInputVal> 
			takeHomeInputValList) {
		log.info("usersCount(): Entered.");
		UsersDTO usersDTO = takeHomeService.usersCount(takeHomeInputValList);
		log.info("usersCount(): Exit.");
		return new ResponseEntity<UsersDTO>(usersDTO, HttpStatus.OK);
	}
	
	@PostMapping("/users/update")
	public ResponseEntity<TakeHomeInputVal> usersUpdate(@RequestBody List<TakeHomeInputVal> 
			takeHomeInputValList) {
		log.info("usersUpdate(): Entered.");
		TakeHomeInputVal takeHomeInputVal = takeHomeService.usersUpdate(takeHomeInputValList);
		log.info("usersUpdate(): Exit.");
		return new ResponseEntity<TakeHomeInputVal>(takeHomeInputVal, HttpStatus.OK);
	}

}
