package com.flowers.takehome.service.impl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.flowers.takehome.dto.TakeHomeDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;
import com.flowers.takehome.service.TakeHomeService;

@Service
public class TakeHomeServiceImpl implements TakeHomeService {
	private static final String FLOWERS = "1800Flowers";
	
	@Override
	public TakeHomeDTO process(final List<TakeHomeInputVal> takeHomeInputValList) {
		final long usersCount = takeHomeInputValList.stream().filter(distinctByKey(u -> u.getUserId())).count();
		TakeHomeInputVal takeHomeInputVal = null;
		TakeHomeDTO takeHomeDTO = new TakeHomeDTO();
		if(takeHomeInputValList.size() >= 4) {
			takeHomeInputVal = takeHomeInputValList.get(3);
			BeanUtils.copyProperties(takeHomeInputVal, takeHomeDTO);
			takeHomeDTO.setTitle(FLOWERS);
			takeHomeDTO.setBody(FLOWERS);
		}
		takeHomeDTO.setUsersCount(usersCount);
		return takeHomeDTO;
	}

    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor)
    {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
}
