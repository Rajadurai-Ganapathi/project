package com.flowers.takehome.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.flowers.takehome.dto.UserDTO;
import com.flowers.takehome.dto.UsersDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;
import com.flowers.takehome.service.TakeHomeService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TakeHomeServiceImpl implements TakeHomeService {
	private static final String FLOWERS = "1800Flowers";
	 
	/**
     * to count the unique user.
     * @param takeHomeInputValList
     * @return UsersDTO
     */
	@Override
	public UsersDTO usersCount(final List<TakeHomeInputVal> takeHomeInputValList) {
		log.info("usersCount(): Entered.");
		//final int usersCount = takeHomeInputValList.stream().filter(distinctByKey(u -> u.getUserId())).count();
		final List<TakeHomeInputVal> uniqueUserList = takeHomeInputValList.stream().filter(distinctByKey(u -> u.getUserId())).collect(Collectors.toList());
		final int usersCount = uniqueUserList.size();
		List<UserDTO>  userList = new ArrayList<UserDTO>();
		uniqueUserList.forEach(user -> {
			UserDTO userDTO = new UserDTO();
			userDTO.setUserId(user.getUserId());
			userList.add(userDTO);
		});
		UsersDTO usersDTO = new UsersDTO();
		usersDTO.setUsersCount(usersCount);
		usersDTO.setUserDTO(userList);
		log.info("usersCount(): Exit.");
		return usersDTO;
	}

	/**
     * to update the user details.
     * @param takeHomeInputValList
     * @return TakeHomeInputVal
     */
	@Override
	public TakeHomeInputVal usersUpdate(final List<TakeHomeInputVal> takeHomeInputValList) {
		log.info("usersUpdate(): Entered.");
		TakeHomeInputVal takeHomeInputVal = null;
		TakeHomeInputVal inputVal = takeHomeInputValList.get(3);
		takeHomeInputVal = new TakeHomeInputVal();
		takeHomeInputVal.setId(inputVal.getId());
		takeHomeInputVal.setUserId(inputVal.getUserId());
		takeHomeInputVal.setBody(FLOWERS);
		takeHomeInputVal.setTitle(FLOWERS);
		log.info("usersUpdate(): Exit.");
		return takeHomeInputVal;
	}
	
    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor)
    {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

}
