package com.flowers.takehome.exception.handling;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;

@RestControllerAdvice
@Slf4j
public class TakeHomeExceptionHandler {
	
	@ExceptionHandler(value = {NullPointerException.class})
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public void handle(NullPointerException ex) {
		//log.error("Exception occurred:", ex);
	}
	
	@ExceptionHandler(value = {IndexOutOfBoundsException.class})
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public void handle(IndexOutOfBoundsException exception) {
		//log.error("Exception occurred:", exception);
	}
	
}