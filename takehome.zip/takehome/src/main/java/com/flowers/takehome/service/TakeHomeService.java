package com.flowers.takehome.service;

import java.util.List;

import com.flowers.takehome.dto.TakeHomeDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;

public interface TakeHomeService {
	TakeHomeDTO process(List<TakeHomeInputVal> takeHomeInputVal);
}
