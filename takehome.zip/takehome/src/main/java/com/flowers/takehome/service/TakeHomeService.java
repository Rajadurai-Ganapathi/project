package com.flowers.takehome.service;

import java.util.List;

import com.flowers.takehome.dto.UsersDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;

public interface TakeHomeService {
	UsersDTO usersCount(List<TakeHomeInputVal> takeHomeInputValList);
	TakeHomeInputVal usersUpdate(List<TakeHomeInputVal> takeHomeInputValList);
}
