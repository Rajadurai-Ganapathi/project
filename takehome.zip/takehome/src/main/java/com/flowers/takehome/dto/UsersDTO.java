package com.flowers.takehome.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class UsersDTO {
	private int usersCount;
	private List<UserDTO> userDTO;
}
