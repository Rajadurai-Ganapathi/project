package com.flowers.takehome.controller;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.flowers.takehome.dto.UserDTO;
import com.flowers.takehome.dto.UsersDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;
import com.flowers.takehome.service.TakeHomeService;

//@RunWith(MockitoJUnitRunner.class)
@RunWith(SpringRunner.class)
@WebMvcTest(value = TakeHomeController.class)
public class TakeHomeControllerTest {
	@Autowired
	private MockMvc mockMvc;
	@MockBean 
	private TakeHomeService takeHomeService;

	String requestString = "[\r\n" + 
			"  {\r\n" + 
			"    \"userId\": 1,\r\n" + 
			"    \"id\": 1,\r\n" + 
			"    \"title\": \"sunt aut facere repellat provident occaecati excepturi optio reprehenderit\",\r\n" + 
			"    \"body\": \"quia et suscipit\\nsuscipit recusandae consequuntur expedita et cum\\nreprehenderit molestiae ut ut quas totam\\nnostrum rerum est autem sunt rem eveniet architecto\"\r\n" + 
			"  }\r\n "+
			"]";
	
	@Test
	public void usersCount() throws Exception {
		String expectedVal = "{\"usersCount\":1}";
		UsersDTO usersDTO = new UsersDTO();
		UserDTO userDTO = new UserDTO();
		long userId = 1;
		userDTO.setUserId(userId);
		usersDTO.setUsersCount(1);
		Mockito.when(takeHomeService.usersCount(Mockito.anyList())).thenReturn(usersDTO);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/takehome/users/count")
				.accept(MediaType.APPLICATION_JSON).content(requestString).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
		assertThat(response.getContentAsString()).isEqualTo(expectedVal);
	}
	
	@Test
	public void usersUpdate() throws Exception {
		TakeHomeInputVal takeHomeInputVal = new TakeHomeInputVal();
		String expectedVal = "{\"userId\":1,\"id\":1,\"title\":\"1800Flowers\",\"body\":\"1800Flowers\"}";
		String flowers = "1800Flowers";
		long id = 1;
		takeHomeInputVal.setUserId(id);
		takeHomeInputVal.setId(id);
		takeHomeInputVal.setTitle(flowers);
		takeHomeInputVal.setBody(flowers);
		Mockito.when(takeHomeService.usersUpdate(Mockito.anyList())).thenReturn(takeHomeInputVal);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/takehome/users/update")
				.accept(MediaType.APPLICATION_JSON).content(requestString).contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertThat(response.getStatus()).isEqualTo(HttpStatus.OK.value());
		assertThat(response.getContentAsString()).isEqualTo(expectedVal);
	}
	 
}
