package com.flowers.takehome.service.impl;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.flowers.takehome.dto.UsersDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class TakeHomeServiceImplTest {

		@InjectMocks
		public TakeHomeServiceImpl takeHomeService;
		
		@Test
		public void usersCount() {
			TakeHomeInputVal inputVal = new TakeHomeInputVal();
			long id = 1;
			inputVal.setUserId(id);
			inputVal.setId(id);
			inputVal.setTitle("Test");
			inputVal.setBody("Test");
			List<TakeHomeInputVal> inputValList = Arrays.asList(inputVal, inputVal, inputVal, inputVal);
			UsersDTO usersDTO = takeHomeService.usersCount(inputValList);
			assertThat(usersDTO.getUsersCount()).isEqualTo(id);
		}
		
		@Test
		public void usersUpdate() {
			String flowers = "1800Flowers";
			TakeHomeInputVal inputVal = new TakeHomeInputVal();
			long id = 1;
			inputVal.setUserId(id);
			inputVal.setId(id);
			inputVal.setTitle("Test");
			inputVal.setBody("Test");
			List<TakeHomeInputVal> inputValList = Arrays.asList(inputVal, inputVal, inputVal, inputVal);
			TakeHomeInputVal takHomeInputVal = takeHomeService.usersUpdate(inputValList);
			assertThat(takHomeInputVal.getTitle()).isEqualTo(flowers);
			assertThat(takHomeInputVal.getBody()).isEqualTo(flowers);
		}
		
}
