package com.flowers.takehome.service.impl;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.flowers.takehome.dto.TakeHomeDTO;
import com.flowers.takehome.inputval.TakeHomeInputVal;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class TakeHomeServiceImplTest {

		@InjectMocks
		public TakeHomeServiceImpl takeHomeService;
		
		@Test
		public void process() {
			String flowers = "1800Flowers";
			TakeHomeInputVal inputVal = new TakeHomeInputVal();
			long id = 1;
			inputVal.setUserId(id);
			inputVal.setId(id);
			inputVal.setTitle("Test");
			inputVal.setBody("Test");
			List<TakeHomeInputVal> inputValList = Arrays.asList(inputVal, inputVal, inputVal, inputVal);
			TakeHomeDTO takeHomeDTO = takeHomeService.process(inputValList);
			assertThat(takeHomeDTO.getUsersCount()).isEqualTo(id);
			assertThat(takeHomeDTO.getTitle()).isEqualTo(flowers);
			assertThat(takeHomeDTO.getBody()).isEqualTo(flowers);
		}
		
}
